#!/usr/bin/perl -w

foreach $line (<>){
    @all_lines = $line =~ /(\d+)/g;
    if (@all_lines > 1){
        $fir = shift @all_lines;  
        $last = pop @all_lines;  
        $line =~ s/$fir/$last/;
        if ($line =~ /(.*)($last)(.*)/){
            $final_line = $1.$fir.$3;
            print "$final_line\n";
        }
    } elsif(@all_lines == 1){
        print "$line";
    } elsif (@all_lines < 1){
        print "$line";
    }
}
