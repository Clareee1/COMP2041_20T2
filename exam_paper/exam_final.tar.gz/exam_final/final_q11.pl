#!/usr/bin/perl -w
sub getNum{
    my $word;
    my @splits;
    my $result;
    my @out;
    $word = $_[0];
    @splits = split("", $word);
    foreach $word(@splits){
        if ($word eq "a" || $word eq "b" || $word eq "c"){
            push @out, "2";
        }
        if ($word eq "d" || $word eq "e" || $word eq "f"){
            push @out, "3";
        }
        if ($word eq "g" || $word eq "h" || $word eq "i"){
            push @out, "4";
        }
        if ($word eq "j" || $word eq "k" || $word eq "l"){
            push @out, "5";
        }
        if ($word eq "m" || $word eq "n" || $word eq "o"){
            push @out, "6";
        }
        if ($word eq "p" || $word eq "q" || $word eq "r" || $word eq "s"){
            push @out, "7";
        }
        if ($word eq "t" || $word eq "u" || $word eq "v"){
            push @out, "8";
        }
        if ($word eq "w" || $word eq "x" || $word eq "y" || $word eq "z"){
            push @out, "9";
        }
        #push @out, $word;
    }
    return @out;
}
open F, "<", $ARGV[0];
@words = <F>;
$numbers = $ARGV[1];
$numbers = $numbers;
foreach $word(@words){
    #print "@words\n";
    @out = getNum($word);
    $out = join("", @out);
    if ($out eq $numbers){
        print "$word";
        #exit 0;
    }
}
#print "\n";
