#!/usr/bin/perl -w

use experimental 'smartmatch';
$dir =$ARGV[0];
@word_list = <$txt>;
close $txt;

while ($line = <STDIN>){
    chomp $line;
    @all_line = split(/\s+/,$line);
    foreach $word (@all_line){
        while ($word =~ /(\w*)\((w+)\)\w*/g){
            $prev=$1;
            $middle=$2;
            $after=$3;
            @m = $middle;
            my @ch = split(//,@m);
            foreach $c (@ch){
                $new=$prev.$c.$after;
                #if this new make word is in the dictionary
                if ($new ~~ @word_list){
                    print "$new ";    
                } 
            }
        }
    }
}
