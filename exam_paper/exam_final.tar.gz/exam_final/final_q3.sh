#!/bin/sh

cut -d'|' -f2 $1|sort|uniq -c|egrep '\s[2]\s'| cut -d' ' -f8
