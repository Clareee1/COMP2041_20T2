#!/bin/dash

min=1000000
max=-10000000
for num in "$@"
do
    if test $num -lt $min
    then
        min=$num
    fi
done


for num in "$@"
do
    if test $num -gt $max
    then
        max=$num
    fi
done

for i in $(seq $min $max)
do
    if echo $* | egrep -v "$i" > /dev/null
    then
        echo $i
    fi
done
