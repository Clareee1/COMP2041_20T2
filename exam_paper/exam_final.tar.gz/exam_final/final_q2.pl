#!/usr/bin/perl -w

%count = ();
while($line = <STDIN>){
    my @info = split(/\|/,$line);
    my $sid = $info[1];
    my $name = $info[2];
    my @name_list=split(/ /,$name);
    my $fir = $name_list[1];
    $count{$sid} = $fir;
}

foreach my $id (sort {$count{$a} cmp $count{$b}} keys %count){
    print "$count{$id}\n";
}
