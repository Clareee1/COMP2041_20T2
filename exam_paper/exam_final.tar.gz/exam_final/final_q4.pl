#!/usr/bin/perl -w

%count = ();
while($line = <STDIN>){
    my @info = split(/\|/,$line);
    my $class = $info[0];
    my $sid = $info[1];
    $count{$sid}++;
}

foreach $sid (sort {$a<=>$b} keys %count){
    print "$sid\n" if $count{$sid} == 2;
}
