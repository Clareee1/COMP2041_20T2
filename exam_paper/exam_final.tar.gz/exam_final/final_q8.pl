#!/usr/bin/perl -w

while ($line =<STDIN>) {
    chomp $line;
    @arr = split(/ /,$line);
    foreach $word (@arr) {
        $prev = $word;
        $word = lc $word;
        @all_word = split(//, $word);
        next if $#all_word == -1;       
        my %count;
        $flag = 0;
        foreach $c (@all_word) {
            $count{$c}++;
        }
        $count = $count{$all_word[0]};    
            
        foreach $ch (keys %count) {
            $flag = 1 if ($count != $count{$ch});
        }   
            print $prev, " " if $flag == 0;
    }
    print "\n";
}
