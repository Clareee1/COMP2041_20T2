#!/bin/sh


assign=0
read=""
for curr in $@
do            
    for new in $@    
    do                 
        if test $curr != $new        
        then            
            if test $(diff $curr $new | wc -l) -eq 0           
            then     
                assignnew=0             
                assigncurr=0                                                             
                for var in $read                
                do                                       
                    if test $var = $new                   
                    then                        
                        assignnew=1                    
                    fi  
                    if test $var = $curr                   
                    then                        
                        assigncurr=1                    
                    fi               
                done
               
                if test $(($assigncurr*$assignnew)) -eq 0  
                then                            
                    echo "ln -s $curr $new"                    
                    read="$read$curr $new "                
               fi                
               assign=1            
            fi        
       fi    
    done
done


if test $assign -eq 0
then    
    echo "No files can be replaced by symbolic links"
fi
