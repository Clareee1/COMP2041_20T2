#!/usr/bin/perl -w
@lines=<>;


foreach $line(@lines){

   if($line=~/(\d+)[^\d]+(\d+)/){
      $line=~s/(\d+)([^\d]+)(\d+)/$3$2$1/;

      
   }
   print $line;
}

