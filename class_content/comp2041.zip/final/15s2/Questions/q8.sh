#!/bin/sh

cut -d "|" -f 4

