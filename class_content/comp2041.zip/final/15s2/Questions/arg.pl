#!/usr/bin/perl 


$ARGV[0] =~ /([^\d]*)(\d+)([^\d]*)/;
$before=$1;
$start=$2;
$after=$3;
$ARGV[1] =~ /([^\d]*)(\d+)([^\d]*)/;
$end=$2;
print "start $start\n";
print "end $end\n";
foreach $num($start..$end){
   print "$before$num$after","\n";
}

