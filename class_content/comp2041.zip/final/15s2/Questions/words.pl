#!/usr/bin/perl

@lines=<>;

foreach $line(@lines){
   @words=$line=~/[a-zA-Z]{3,}/g;
   foreach $word(@words){
      $tmp =$word;
      $tmp=~/([a-zA-Z])([a-zA-Z]+)([a-zA-Z])/;
      $front =$1;
      $middle =$2;
      $back = $3;
      @tmp=(split "",$middle);
      grep { $_ ='-'} @tmp;
      $middle = join("",@tmp);
      
      $line =~ s/[a-zA-Z]{3,}/$front$middle$back/g;
   }
   print $line;
    

  
   

}



