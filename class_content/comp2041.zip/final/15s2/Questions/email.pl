#!/usr/bin/perl

@lines=<>;

foreach $line(@lines){
   $line=~s/([^ \n]+)@[^ \n]+/$1\@example.com/g;
   print $line,;
   

}



