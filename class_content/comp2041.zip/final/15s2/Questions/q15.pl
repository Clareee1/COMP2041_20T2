#!/usr/bin/perl
@words=<STDIN>;
grep {chomp $_} @words;
%cost=();
%visited=();
%spt=();
$root=$ARGV[0];
$target=$ARGV[1];
$cost{$root}=0;
$spt{$root}=$root;
while(1==1){
   my $next=min(\%cost,\%visited);
   if($next eq ""){
      last;
   }
   $visited{$next}=1;
   
   foreach my $word(@words){
      
      if(adjacant($word,$next)==1 && $word ne $next){
         #print "$word are ad to $next";
         if(! exists $spt{$word} ||$cost{$next}+1 <$cost{$word}){#infinite or shorter
            $spt{$word}=$next;
            $cost{$word}=$cost{$next}+1;
         }
      }
   
   }

}


$tmp= $target;
while($tmp ne $root){
   print $tmp,"\n";
   $tmp=$spt{$tmp};
}
print $cost{$target},"\n";




sub min{
   my ($cos,$visits)=@_;
   my %costs=%{$cos};
   my %visied=%{$visits};
   my @keyy= sort {$costs{$a}<=>$costs{$b}}keys(%costs);
   foreach my $tmp(@keyy){
   
      if(!exists $visied{$tmp}){
      
         return $tmp;
      }
   }
   return "";
   


}

sub adjacant{
   my($str1,$str2)=@_;
   @arr1=split "",$str1;
   @arr2=split "",$str2;
   my $changes=0;
   foreach my $n(0..$#arr1){
      if($arr1[$n] ne $arr2[$n]){
           $changes++;
      
      }
   
   }
   if($changes==1){
      return 1;
   }
   return 0;
}





