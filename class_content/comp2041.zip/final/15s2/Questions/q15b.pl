#!/usr/bin/perl -w
@words=<>;
@copy=@words;
%count=();
foreach $n(0..$#copy){
   
   $copy[$n]= join("",sort(split("",$copy[$n])));
   if(!exists $count{$copy[$n]}){
      $count{$copy[$n]}[0]=$words[$n];
   }else{
      push(@{$count{$copy[$n]}},$words[$n]);
   }
   
}


foreach $key (keys(%count)){

   foreach $word (@{$count{$key}}){
      chomp $word;
      print $word," ";
   }
   print "\n";
   
}



