#!/usr/bin/perl 

@nums=<>;

@nums=sort{$a<=>$b} @nums;

$min = $nums[0];

while(1==1){
   if(exist($min ,\@nums)==0){
   
      print $min,"\n";
      exit 0;
   }
   $min+=1;
}



sub exist{
   my ($num,$ns)=@_;
   @numbers=@{$ns};
   foreach my $n(@numbers){
   
      if($n==$num){
         return 1;
      
      }
   }
   return 0;
   
   


}



